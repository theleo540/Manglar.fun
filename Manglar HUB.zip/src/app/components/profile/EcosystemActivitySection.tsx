import { useRef, useState } from "react";
import { Film, Heart, Bookmark, Link2, MousePointerClick, ChevronLeft, ChevronRight } from "lucide-react";
import { useEcosystemActivity } from "@/hooks/useEcosystemActivity";
import { ImageWithFallback } from "@/components/figma/ImageWithFallback";
import { AnimePreviewModal } from "@/web/anime";
import { HentaiPreviewModal } from "@/web/hentai";
import type { ProductActivity } from "@/types/activity";
import type { EcosystemAnimeItem } from "@/web/shared/types";

const GOCUT_URL = "https://gocut.manglar.fun";

// Mismos dominios reales que ECOSYSTEM_PROJECTS (config/ecosystem.ts,
// footerUrl de manglaranime/manglarhentai) -- se usan como `domain` del
// preview modal, igual que en el Hero.
const ANIME_URL = "https://anime.manglar.fun";
const HENTAI_URL = "https://hentai.manglar.fun";

function toAnimeItem(itemId: string, title: string, posterUrl: string): EcosystemAnimeItem {
  // El preview modal solo necesita id/title/poster(/backdrop) — no
  // guardamos backdrop en la actividad, así que usamos el poster como
  // respaldo (mismo criterio que AnimePreviewModal ya usa internamente
  // cuando no hay backdropUrl).
  return { id: itemId, title, posterUrl, backdropUrl: posterUrl, type: null };
}

function MiniStat({ icon, label, value }: { icon: React.ReactNode; label: string; value: number }) {
  return (
    <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-white/[0.03] border border-white/[0.06]">
      <span className="text-emerald-400">{icon}</span>
      <span className="text-sm font-semibold text-white font-mono">{value}</span>
      <span className="text-xs text-slate-500">{label}</span>
    </div>
  );
}

function Poster({ title, posterUrl, sub, onOpen }: { title: string; posterUrl: string; sub?: string; onOpen: () => void }) {
  return (
    <button
      type="button"
      onClick={onOpen}
      className="flex-shrink-0 w-[100px] sm:w-[120px] text-left group"
      title={`Ver "${title}"`}
    >
      <div className="w-full aspect-[2/3] rounded-lg overflow-hidden bg-[#0d1117] border border-white/[0.06] group-hover:border-emerald-400/40 transition-colors">
        {posterUrl ? (
          <ImageWithFallback
            src={posterUrl}
            alt={title}
            className="w-full h-full object-cover"
            loading="lazy"
            decoding="async"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-slate-600">
            <Film className="w-6 h-6" />
          </div>
        )}
      </div>
      <p className="text-xs text-slate-300 mt-1.5 line-clamp-2 leading-snug group-hover:text-emerald-400 transition-colors">
        {title}
      </p>
      {sub && <p className="text-[10px] text-slate-600 mt-0.5">{sub}</p>}
    </button>
  );
}

/**
 * Fila horizontal con botones de deslizar (< / >) a los costados. Sin
 * esto la única forma de ver los posters que no entran en pantalla era
 * arrastrar con el mouse/dedo -- nada indicaba que se podía deslizar.
 */
function ScrollRow({ children }: { children: React.ReactNode }) {
  const ref = useRef<HTMLDivElement>(null);

  function scrollBy(dir: 1 | -1) {
    ref.current?.scrollBy({ left: dir * 320, behavior: "smooth" });
  }

  return (
    <div className="relative group/row">
      <div ref={ref} className="flex gap-3 overflow-x-auto pb-1 scroll-smooth" style={{ scrollbarWidth: "none" }}>
        {children}
      </div>

      <button
        type="button"
        onClick={() => scrollBy(-1)}
        aria-label="Deslizar hacia la izquierda"
        className="hidden sm:flex items-center justify-center absolute left-0 top-0 bottom-1 w-9 bg-gradient-to-r from-[#161B22] to-transparent text-white opacity-0 group-hover/row:opacity-100 transition-opacity"
      >
        <ChevronLeft className="w-5 h-5" />
      </button>
      <button
        type="button"
        onClick={() => scrollBy(1)}
        aria-label="Deslizar hacia la derecha"
        className="hidden sm:flex items-center justify-center absolute right-0 top-0 bottom-1 w-9 bg-gradient-to-l from-[#161B22] to-transparent text-white opacity-0 group-hover/row:opacity-100 transition-opacity"
      >
        <ChevronRight className="w-5 h-5" />
      </button>
    </div>
  );
}

function SectionShell({ title, action, children }: { title: string; action?: React.ReactNode; children: React.ReactNode }) {
  return (
    <div className="rounded-2xl border border-white/[0.08] bg-[#161B22] p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-sm font-semibold text-white">{title}</h3>
        {action}
      </div>
      {children}
    </div>
  );
}

function EmptyRow({ text }: { text: string }) {
  return <p className="text-sm text-slate-500">{text}</p>;
}

/**
 * Una sección completa (ManglarAnime o ManglarHentai): stats + filas con
 * deslizar. Al picarle a una tarjeta se abre el mismo preview modal que
 * usa el sitio real (y el Hero del home) en vez de mandar directo afuera
 * -- desde ahí "Ver ahora" sí manda al título exacto.
 */
function ProductSection({
  title,
  url,
  kind,
  data,
}: {
  title: string;
  url: string;
  kind: "anime" | "hentai";
  data: ProductActivity;
}) {
  const [preview, setPreview] = useState<EcosystemAnimeItem | null>(null);
  const hasActivity = data.continueWatching.length > 0 || data.likes.length > 0 || data.listCount > 0 || data.completedCount > 0;
  const PreviewModal = kind === "hentai" ? HentaiPreviewModal : AnimePreviewModal;

  return (
    <SectionShell
      title={title}
      action={
        <a href={url} target="_blank" rel="noopener noreferrer" className="text-xs text-emerald-400 hover:underline">
          Ir al sitio →
        </a>
      }
    >
      <div className="flex flex-wrap gap-2 mb-5">
        <MiniStat icon={<Heart className="w-3.5 h-3.5" />} label="likes" value={data.likesCount} />
        <MiniStat icon={<Bookmark className="w-3.5 h-3.5" />} label="en tu lista" value={data.listCount} />
        <MiniStat icon={<Film className="w-3.5 h-3.5" />} label="completados" value={data.completedCount} />
      </div>

      {!hasActivity && <EmptyRow text="Todavía no tenés actividad acá." />}

      {data.continueWatching.length > 0 && (
        <div className="mb-5">
          <p className="text-xs font-medium text-slate-400 mb-2.5">Continuar viendo</p>
          <ScrollRow>
            {data.continueWatching.map((item) => (
              <Poster
                key={`${item.itemId}-${item.product}`}
                title={item.title}
                posterUrl={item.posterUrl}
                sub={item.totalEpisodes ? `Ep. ${item.episodesWatched}/${item.totalEpisodes}` : undefined}
                onOpen={() => setPreview(toAnimeItem(item.itemId, item.title, item.posterUrl))}
              />
            ))}
          </ScrollRow>
        </div>
      )}

      {data.likes.length > 0 && (
        <div>
          <p className="text-xs font-medium text-slate-400 mb-2.5">Tus likes</p>
          <ScrollRow>
            {data.likes.map((item) => (
              <Poster
                key={`${item.itemId}-${item.product}`}
                title={item.title}
                posterUrl={item.posterUrl}
                onOpen={() => setPreview(toAnimeItem(item.itemId, item.title, item.posterUrl))}
              />
            ))}
          </ScrollRow>
        </div>
      )}

      {preview && <PreviewModal item={preview} domain={url} onClose={() => setPreview(null)} />}
    </SectionShell>
  );
}

/**
 * Recopilación real de actividad del usuario en los productos del
 * ecosistema (ManglarAnime, ManglarHentai, GoCut), leída directo de
 * Supabase. Cada tarjeta abre el preview modal real del título (mismo
 * componente que usa el Hero del home), no un link directo afuera.
 */
export function EcosystemActivitySection({ ownerEmail }: { ownerEmail: string }) {
  const { activity, loading } = useEcosystemActivity(ownerEmail);

  if (loading) {
    return (
      <div className="space-y-4">
        <div className="h-40 rounded-2xl border border-white/[0.08] bg-[#161B22] animate-pulse" />
        <div className="h-40 rounded-2xl border border-white/[0.08] bg-[#161B22] animate-pulse" />
      </div>
    );
  }

  if (!activity) return null;

  const { anime, hentai, gocut } = activity;
  const hasAnyActivity =
    anime.continueWatching.length > 0 ||
    anime.likes.length > 0 ||
    anime.listCount > 0 ||
    anime.completedCount > 0 ||
    hentai.continueWatching.length > 0 ||
    hentai.likes.length > 0 ||
    hentai.listCount > 0 ||
    hentai.completedCount > 0 ||
    gocut.links.length > 0;

  if (!hasAnyActivity) {
    return (
      <SectionShell title="Tu actividad en el ecosistema">
        <EmptyRow text="Todavía no tenés actividad en ManglarAnime, ManglarHentai ni en GoCut. Cuando veas algo, le des like, o acortes un link, va a aparecer acá." />
      </SectionShell>
    );
  }

  return (
    <div className="space-y-6 min-w-0">
      <ProductSection title="ManglarAnime" url={ANIME_URL} kind="anime" data={anime} />
      <ProductSection title="ManglarHentai" url={HENTAI_URL} kind="hentai" data={hentai} />

      <SectionShell
        title="GoCut"
        action={
          <a href={GOCUT_URL} target="_blank" rel="noopener noreferrer" className="text-xs text-emerald-400 hover:underline">
            Ir al sitio →
          </a>
        }
      >
        <div className="flex flex-wrap gap-2 mb-5">
          <MiniStat icon={<Link2 className="w-3.5 h-3.5" />} label="links creados" value={gocut.linksCount} />
          <MiniStat icon={<MousePointerClick className="w-3.5 h-3.5" />} label="clicks totales" value={gocut.totalClicks} />
        </div>

        {gocut.links.length > 0 ? (
          <div className="space-y-2">
            {gocut.links.map((link) => (
              <a
                key={link.slug}
                href={`${GOCUT_URL}/${link.slug}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-between gap-3 px-3.5 py-2.5 rounded-lg bg-white/[0.03] border border-white/[0.06] hover:border-emerald-400/40 transition-colors group"
              >
                <div className="min-w-0">
                  <p className="text-sm text-emerald-400 font-mono truncate">gocut.link/{link.slug}</p>
                  <p className="text-xs text-slate-500 truncate">{link.longUrl}</p>
                </div>
                <span className="flex-shrink-0 text-xs text-slate-400 font-mono">{link.clicks} clicks</span>
              </a>
            ))}
          </div>
        ) : (
          <EmptyRow text="Todavía no creaste ningún link." />
        )}
      </SectionShell>
    </div>
  );
}
